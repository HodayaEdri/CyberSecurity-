# Reflection: Evidence vs. Intuition (Lab 2b – Sustained Profile)

**Run ID:** `85fcd3be` (`sustained`) vs. `7dd9bb23` (`normal`)

### 1. What did the dashboard initially suggest?
במבט ראשון בלוח הבקרה בזמן הריצה, קל להניח שכל צינור העיבוד "איטי" או שה-Orchestrator מתקשה להתמודד עם עומס ההתראות, משום שזמן ההשהיה מקצה לקצה (E2E Latency) טיפס בהתמדה מעל 4.5 דקות וקצב פליטת ההתראות הסופי נראה נמוך ביחס לקצב הזרמת האירועים.

### 2. What did the CSV confirm or contradict?
ניתוח קובץ ה-CSV סתר את ההנחה שהבעיה נעוצה ב-Orchestrator או בזמן החישוב של הסוכנים:
* **זמני עיבוד יציבים:** הקובץ אישר שזמני העיבוד הפעילים (`stage_latency_ms`) נשארו מהירים ויציבים גם תחת עומס כבד — `90.06 ms` בממוצע ב-Detector ו-`30.34 ms` ב-Orchestrator.
* **מיקום הצוואר הבקבוק:** תור ההתראות בין הגלאי למתזמר (`alert_backlog`) לא עלה על 8 התראות, והמתנת התור של ה-Orchestrator עמדה על `8.15 ms` בלבד. הנתונים הוכיחו ש-**99.97%** מזמן ההשהיה הכולל (`142,938 ms` מתוך `142,980 ms`) נבע מהמתנה בתור הכניסה של ה-Detector ב-Redpanda, ולא מעיכוב בשכבת הסוכנים.

### 3. What uncertainty remains in your bottleneck diagnosis?
קובץ ה-CSV מודד זמני תור ועיבוד ברמת התהליך בפייתון, אך אינו חושף איזה משאב מערכת הגביל את ה-Detector לתקרה של `~10.5 events/s`:
* האם המגבלה נובעת מרוויה של **CPU** (חישוב מודל ה-Isolation Forest ועדכון פרופילים לכל אירוע בנפרד).
* האם המגבלה נובעת מתקורת **Network / I/O** מול Redpanda עקב שליפה ופרסום של הודעה בודדת בכל פעם ללא Batching.
* או שמדובר בתחרות משאבים (**OS Process Scheduling**) על מחשב מקומי יחיד שמריץ במקביל קונטיינרים של Docker וארבעה תהליכי פייתון.

### 4. What would you change in the architecture and why?
הייתי משנה את ארכיטקטורת הקליטה והעיבוד של ה-Detector בשני צעדים משלימים:
1. **עיבוד במנות (Micro-batching):** במקום לקרוא ולנתח אירוע בודד בכל איטרציה, לאפשר ל-Detector למשוך אצווה של אירועים (למשל 32–64 אירועים) ולבצע הסקה וקטורית מהירה ב-Isolation Forest, מה שמקטין דרמטית את תקורת התקשורת מול Kafka.
2. **מקביליות אופקית (Horizontal Scaling):** הגדלת מספר ה-Partitions בנושא `raw.logs` והרצת מספר מופעים מקביליים של `morpheus_lite_detector.py` באותה Consumer Group, תוך ניהול מצב טביעות האצבע (`fingerprint_profiles`) באחסון משותף ומהיר (כגון Redis) כדי למנוע צבירת תורים של דקות בזמן עומס מתמשך.